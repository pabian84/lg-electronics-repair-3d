import { LEFT_DOOR_DAMPER_NODE_NAME } from '../../shared/utils/fridgeConstants';
import * as THREE from 'three';
import { getPreciseBoundingBox } from '../../shared/utils/commonUtils';
import { animate, calculateCameraTargetPosition, NodeCache } from '../../shared/utils/animationUtils';

// Camera movement options
export interface CameraMoveOptions {
    duration?: number; // milliseconds
    zoomRatio?: number; // Custom zoom ratio
    direction?: THREE.Vector3; // Custom camera direction
    onProgress?: (progress: number) => void; // Progress callback
}

// Camera movement service for fridge animations
export class CameraMovementService {
    private cameraControls: any;
    private sceneRoot: THREE.Object3D | null = null;
    private nodeCache: NodeCache = new NodeCache();

    constructor(cameraControls: any, sceneRoot?: THREE.Object3D) {
        this.cameraControls = cameraControls;
        this.sceneRoot = sceneRoot || null;
    }

    // Set scene root reference for node lookup
    public setSceneRoot(sceneRoot: THREE.Object3D): void {
        this.sceneRoot = sceneRoot;
        this.nodeCache.clear(); // Clear cache when scene root changes
    }

    public async moveCameraToNode(nodeName: string, options: CameraMoveOptions = {}): Promise<void> {
        // 단순히 시네마틱 로직을 실행하도록 연결
        return this.moveCameraCinematic(nodeName);
    }

    private drawCameraPath(points: THREE.Vector3[]): void {
        if (!this.sceneRoot) return;

        // 1. 점을 연결하는 곡선 생성
        const curve = new THREE.CatmullRomCurve3(points);
        const curvePoints = curve.getPoints(100); // 100개의 세밀한 점 추출

        // 2. 지오메트리 생성 및 점선 패턴 계산
        const geometry = new THREE.BufferGeometry().setFromPoints(curvePoints);

        // 3. 두꺼운 선 재질 설정 (빨간색 실선)
        const material = new THREE.LineBasicMaterial({
            color: 0xff0000,
            linewidth: 15, // 두꺼운 선
        });

        const line = new THREE.Line(geometry, material);

        // 4. 씬에 추가 (디버깅용 객체임을 식별하기 위해 이름 부여)
        line.name = "DEBUG_CAMERA_PATH";
        this.sceneRoot.add(line);

        // 5. 10초 후 자동 제거 (화면 유지 시간 조절 가능)
        /* setTimeout(() => {
            if (this.sceneRoot) this.sceneRoot.remove(line);
        }, 10000); */
    }

    private async moveCameraCinematic(nodeName: string, options: CameraMoveOptions = {}): Promise<void> {
        const targetNode = this.getNodeByName(nodeName);
        if (!targetNode || !this.cameraControls) {
            console.warn(`Node '${nodeName}' not found or controls not ready.`);
            return;
        }

        // 1. 대상의 위치 및 크기 파악 (BoundingBox)
        const box = getPreciseBoundingBox(targetNode);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z);

        // 2. 현재 카메라 상태 캡처
        const startPos = this.cameraControls.camera.position.clone();
        const startTarget = this.cameraControls.target ? this.cameraControls.target.clone() : new THREE.Vector3();

        // 3. 목표 위치 계산 (Low Angle Target)
        // - 거리는 객체 크기 기반 ZoomRatio 적용
        // - 핵심: Y축을 낮춰서(Center - Offset) 올려다보는 구도 형성
        const dist = maxDim * (options.zoomRatio || 2.5);

        // 카메라가 대상을 바라볼 최종 위치 (정면에서 약간 아래)
        // 방향 벡터 계산 (현재 위치에서 대상 방향)
        const dirToTarget = new THREE.Vector3().subVectors(center, startPos).normalize();
        dirToTarget.y = 0; // 수평 거리만 고려하기 위해 Y 제거

        const endPos = center.clone()
            .addScaledVector(dirToTarget.normalize(), -dist) // 뒤로 물러남
            .setY(center.y - size.y * 0.5); // [Low Angle] 대상의 하단부 높이로 이동

        // 4. 베지에 곡선 제어점 (Control Point) 최적화
        // - "목적지 바로 위쪽"에 제어점을 배치하여 'ㄱ'자 궤적 유도
        // - 시작점의 높이(Y)와 도착점의 평면좌표(X, Z)를 결합
        const controlPoint = new THREE.Vector3(
            endPos.x,       // 도착점 X
            Math.max(startPos.y, endPos.y + size.y * 2), // 시작 높이 유지 (혹은 더 높게)
            endPos.z        // 도착점 Z
        );

        const curve = new THREE.QuadraticBezierCurve3(startPos, controlPoint, endPos);

        // 5. 애니메이션 루프 실행
        const duration = options.duration || 1500;

        return new Promise((resolve) => {
            let startTime: number | null = null;

            const animateStep = (timestamp: number) => {
                if (!startTime) startTime = timestamp;
                const elapsed = timestamp - startTime;
                const rawProgress = Math.min(elapsed / duration, 1);

                // [Asymmetric Easing] 비대칭 이징 적용
                // progress^5를 사용하여 초반엔 천천히, 막판에 급격히 변화 (Drop 효과 극대화)
                const easedProgress = Math.pow(rawProgress, 5);

                // 5-1. 곡선 경로 상의 위치 계산
                const newPos = curve.getPoint(easedProgress);
                this.cameraControls.setPosition(newPos.x, newPos.y, newPos.z, false); // false = don't update yet

                // 5-2. 시선(Target)은 부드럽게 대상 중심으로 고정
                // LookAt은 Easing을 덜 강하게(Cubic) 주어 시선이 너무 늦게 따라오지 않도록 함
                const lookAtEasing = 1 - Math.pow(1 - rawProgress, 3);
                const newTarget = new THREE.Vector3().lerpVectors(startTarget, center, lookAtEasing);
                this.cameraControls.setTarget(newTarget.x, newTarget.y, newTarget.z, false);

                // 업데이트 적용
                this.cameraControls.update(0);

                if (rawProgress < 1) {
                    requestAnimationFrame(animateStep);
                } else {
                    resolve();
                }
            };

            requestAnimationFrame(animateStep);
        });
    }

    /**
     * [추가] webp 시나리오: 커버 -> 레버 -> 힌지 순으로 카메라가 추적하는 시퀀스
     */
    public async playDisassemblyCameraSequence(): Promise<void> {
        // 1단계: 도어 커버 집중 (정면 사선)
        await this.moveCameraToNode("Door_Cover", { duration: 1200, zoomRatio: 2 });

        // 2단계: 레버 분리 시점에 맞춰 상단으로 이동
        await new Promise(resolve => setTimeout(resolve, 500)); // 애니메이션 타이밍 동기화
        await this.moveCameraToNode("Lever_Part", { duration: 1000, direction: new THREE.Vector3(0, 1, 0.5) });

        // 3단계: 힌지 분리 시점에 맞춰 측면 집중
        await this.moveCameraToNode("Hinge_Assembly", { duration: 1000, zoomRatio: 1.2 });
    }

    // Find a node by name in the scene (with caching)
    private getNodeByName(nodeName: string): THREE.Object3D | null {
        if (!this.sceneRoot) {
            console.error('Scene root not available for node lookup');
            return null;
        }

        return this.nodeCache.findNodeByName(this.sceneRoot, nodeName);
    }


    // Default camera movement parameters
    private static readonly DEFAULT_DAMPER_DURATION = 1000;

    // Move camera to the left door damper node (Promise-based)
    public async moveCameraToLeftDoorDamper(options: CameraMoveOptions = {}): Promise<void> {
        console.log('moveCameraToLeftDoorDamper!!');
        await this.moveCameraToNode(LEFT_DOOR_DAMPER_NODE_NAME, {
            duration: options.duration || CameraMovementService.DEFAULT_DAMPER_DURATION,
            // Ensure horizontal direction for front view
            direction: new THREE.Vector3(1, 0, 0).normalize(),
            ...options
        });
    }
}
