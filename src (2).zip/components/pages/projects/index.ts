export { default as ProjectsFrame } from "./ProjectsFrame";
export { default as ProjectsHeader } from "./ProjectsHeader";
export { default as ProjectsTable } from "./ProjectsTable";
export { default as ProjectDetail } from "./ProjectDetail";
export type { Project } from "./types";
