import { LEFT_DOOR_DAMPER_NODE_NAME } from '../../shared/utils/fridgeConstants';
import * as THREE from 'three';
import { getPreciseBoundingBox } from '../../shared/utils/commonUtils';
import { animate, calculateCameraTargetPosition, NodeCache } from '../../shared/utils/animationUtils';

// Camera movement options
export interface CameraMoveOptions {
    duration?: number; // milliseconds
    zoomRatio?: number; // Custom zoom ratio
    direction?: THREE.Vector3; // Custom camera direction
    onProgress?: (progress: number) => void; // Progress callback
}

// Camera movement service for fridge animations
export class CameraMovementService {
    private cameraControls: any;
    private sceneRoot: THREE.Object3D | null = null;
    private nodeCache: NodeCache = new NodeCache();

    constructor(cameraControls: any, sceneRoot?: THREE.Object3D) {
        this.cameraControls = cameraControls;
        this.sceneRoot = sceneRoot || null;
    }

    // Set scene root reference for node lookup
    public setSceneRoot(sceneRoot: THREE.Object3D): void {
        this.sceneRoot = sceneRoot;
        this.nodeCache.clear(); // Clear cache when scene root changes
    }

    public async moveCameraToNode(nodeName: string, options: CameraMoveOptions = {}): Promise<void> {
        // 단순히 시네마틱 로직을 실행하도록 연결
        return this.moveCameraCinematic(nodeName);
    }

    private drawCameraPath(points: THREE.Vector3[]): void {
        if (!this.sceneRoot) return;

        // 1. 점을 연결하는 곡선 생성
        const curve = new THREE.CatmullRomCurve3(points);
        const curvePoints = curve.getPoints(100); // 100개의 세밀한 점 추출

        // 2. 지오메트리 생성 및 점선 패턴 계산
        const geometry = new THREE.BufferGeometry().setFromPoints(curvePoints);

        // 3. 두꺼운 선 재질 설정 (빨간색 실선)
        const material = new THREE.LineBasicMaterial({
            color: 0xff0000,
            linewidth: 15, // 두꺼운 선
        });

        const line = new THREE.Line(geometry, material);

        // 4. 씬에 추가 (디버깅용 객체임을 식별하기 위해 이름 부여)
        line.name = "DEBUG_CAMERA_PATH";
        this.sceneRoot.add(line);

        // 5. 10초 후 자동 제거 (화면 유지 시간 조절 가능)
        /* setTimeout(() => {
            if (this.sceneRoot) this.sceneRoot.remove(line);
        }, 10000); */
    }

    /**
     * [LG CNS 최종 개선안] 
     * 1. Longest Axis Awareness: 객체의 장축에 맞춰 정면/측면 자동 선택
     * 2. Orthogonal Alignment: 비스듬한 뷰를 제거하고 완전한 수평 정렬 후 접근
     * 3. Path Visualization: drawCameraPath를 호출하여 이동 궤적을 빨간 선으로 표시
    */
    public async moveCameraCinematic(nodeName: string): Promise<void> {
        const targetNode = this.getNodeByName(nodeName);
        if (!targetNode || !this.sceneRoot) return;

        // 0. 타겟 바운딩 박스 및 크기 분석
        const targetBox = getPreciseBoundingBox(targetNode);
        const targetCenter = new THREE.Vector3();
        targetBox.getCenter(targetCenter);
        const size = new THREE.Vector3();
        targetBox.getSize(size);

        // [Longest Axis Awareness] 가로(X)와 깊이(Z)를 비교하여 정면/측면 결정
        // 축 성분을 (0,0,1) 또는 (1,0,0)으로 엄격히 제한하여 비스듬함을 원천 차단합니다.
        const isWide = size.x >= size.z;
        const horizontalDir = isWide
            ? new THREE.Vector3(0, 0, 1)  // 가로가 길면 정면(Z축) 주시
            : new THREE.Vector3(1, 0, 0); // 깊이가 길면 측면(X축) 주시

        // 1단계 목표: 전체 조망 정렬 위치 (Alignment Position)
        const sceneBox = getPreciseBoundingBox(this.sceneRoot);
        const sceneSize = new THREE.Vector3();
        sceneBox.getSize(sceneSize);
        const safetyDistance = Math.max(sceneSize.x, sceneSize.y, sceneSize.z) * 1.5;
        const alignPos = targetCenter.clone().add(horizontalDir.clone().multiplyScalar(safetyDistance));

        // 2단계 목표: 최종 줌인 및 로우 앵글 위치 (Final Position)
        const diagonal = targetBox.min.distanceTo(targetBox.max);
        const fovRad = (this.cameraControls.object.fov * Math.PI) / 180;
        const zoomDistance = (diagonal / 2) / Math.tan(fovRad / 2);
        const finalPos = targetCenter.clone().add(horizontalDir.clone().multiplyScalar(zoomDistance));
        finalPos.y -= (size.y * 1.2); // 아래에서 위를 보도록 하강

        // Bezier 제어점: 이동 경로 중간까지는 수평(직선)을 유지하도록 설정
        const controlPos = new THREE.Vector3(
            (alignPos.x + finalPos.x) / 2,
            targetCenter.y, // 타겟 높이를 유지하여 직선 줌인 느낌 강조
            (alignPos.z + finalPos.z) / 2
        );

        // ---------------------------------------------------------
        // [추가 요구사항] 카메라 궤적 선 그리기 (Phase 1 + Phase 2)
        // ---------------------------------------------------------
        const startPos1 = this.cameraControls.object.position.clone();
        const pathPoints: THREE.Vector3[] = [startPos1]; // 시작점
        pathPoints.push(alignPos); // 1단계 정렬점 (직선)

        const zoomCurve = new THREE.QuadraticBezierCurve3(alignPos, controlPos, finalPos);
        pathPoints.push(...zoomCurve.getPoints(50)); // 2단계 줌인 곡선 샘플링

        this.drawCameraPath(pathPoints); // 궤적 시각화 실행

        // ---------------------------------------------------------
        // 애니메이션 실행
        // ---------------------------------------------------------
        const startTarget1 = this.cameraControls.target.clone();

        // Phase 1: 축 정렬 (이동 중 비스듬한 상태를 수평/정면으로 교정)
        await animate((progress: number, eased: number) => { // 타입을 명시적으로 지정
            this.cameraControls.object.position.lerpVectors(startPos1, alignPos, eased);
            this.cameraControls.target.lerpVectors(startTarget1, targetCenter, eased);
            this.cameraControls.update();
        }, { duration: 1000 });

        // Phase 2: 시네마틱 줌인 (Bezier 곡선을 따라 직선 줌 후 하강)
        const startTarget2 = this.cameraControls.target.clone();
        const originalDamping = this.cameraControls.enableDamping;
        this.cameraControls.enableDamping = false;

        await animate((progress: number, eased: number) => { // 타입을 명시적으로 지정
            const point = zoomCurve.getPoint(eased);
            this.cameraControls.object.position.copy(point);
            this.cameraControls.target.lerpVectors(startTarget2, targetCenter, eased);
            this.cameraControls.update();
        }, {
            duration: 2500,
            easing: (t: number) => t * (2 - t) // easing 함수의 매개변수 t에도 타입을 지정하는 것이 좋습니다.
        });

        this.cameraControls.enableDamping = originalDamping;
    }

    /**
     * [추가] webp 시나리오: 커버 -> 레버 -> 힌지 순으로 카메라가 추적하는 시퀀스
     */
    public async playDisassemblyCameraSequence(): Promise<void> {
        // 1단계: 도어 커버 집중 (정면 사선)
        await this.moveCameraToNode("Door_Cover", { duration: 1200, zoomRatio: 2 });

        // 2단계: 레버 분리 시점에 맞춰 상단으로 이동
        await new Promise(resolve => setTimeout(resolve, 500)); // 애니메이션 타이밍 동기화
        await this.moveCameraToNode("Lever_Part", { duration: 1000, direction: new THREE.Vector3(0, 1, 0.5) });

        // 3단계: 힌지 분리 시점에 맞춰 측면 집중
        await this.moveCameraToNode("Hinge_Assembly", { duration: 1000, zoomRatio: 1.2 });
    }

    // Find a node by name in the scene (with caching)
    private getNodeByName(nodeName: string): THREE.Object3D | null {
        if (!this.sceneRoot) {
            console.error('Scene root not available for node lookup');
            return null;
        }

        return this.nodeCache.findNodeByName(this.sceneRoot, nodeName);
    }


    // Default camera movement parameters
    private static readonly DEFAULT_DAMPER_DURATION = 1000;

    // Move camera to the left door damper node (Promise-based)
    public async moveCameraToLeftDoorDamper(options: CameraMoveOptions = {}): Promise<void> {
        console.log('moveCameraToLeftDoorDamper!!');
        await this.moveCameraToNode(LEFT_DOOR_DAMPER_NODE_NAME, {
            duration: options.duration || CameraMovementService.DEFAULT_DAMPER_DURATION,
            // Ensure horizontal direction for front view
            direction: new THREE.Vector3(1, 0, 0).normalize(),
            ...options
        });
    }
}
